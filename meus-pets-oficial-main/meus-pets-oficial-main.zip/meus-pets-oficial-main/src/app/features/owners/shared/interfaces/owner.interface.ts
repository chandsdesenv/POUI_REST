export interface Owner {
  id: string;
  name: string;
  rg: string;
  cpf: string;
  email: string;
  tel1: string;
  tel2: string;
}
